select * from jobs_table
select * from company_table
select * from detail_table

ALTER TABLE jobs_table
ADD PRIMARY KEY (job_id)

ALTER TABLE company_table
ADD PRIMARY KEY (company_id)

ALTER TABLE detail_table
ADD PRIMARY KEY (detail_id)





